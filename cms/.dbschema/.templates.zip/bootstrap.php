<?php
$a = Cetera\Application::getInstance();

// Сервер
$s = $a->getServer();

// Активный раздел
$c = $a->getCatalog();

$twig = $a->getTwig();

$twig->addGlobal('s',  $_SERVER);
$twig->addGlobal('server',  $s);
$twig->addGlobal('catalog', $c);
$twig->addGlobal('application', $a);