<?php
$twig->display('page_index.twig');